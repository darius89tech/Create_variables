var age = 10
var height = 42
//in order to ride the ride the rider must be a minimum of age 10 and a minimum height of 42 inches
if (height >= 42){
    console.log ("get on the ride kiddo")
}
else {
    console.log ("sorry kiddo. Maybe next year")
}
if (age >= 10){
    console.log ("you are old enough")
}
else {
    console.log (" sorry kiddo. you are to young")
}
