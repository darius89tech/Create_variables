var age = 10
var height = 42
//in order to ride the ride the rider must be a minimum of age 10 and a minimum height of 42 inches
